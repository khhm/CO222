/*
   R - Rock
   C - Scissors
   L - Lizard
   P - Paper
   S - Spock  
*/





#include<stdio.h>



int main(){



char player1,player2;   // Initialize Player 1 & Player 2 variables

int output=0;



scanf("%c %c",&player1,&player2);  // here get player 1 & player 2 inputs




if( (player1=='L' || player1=='R' || player1=='S' || player1=='C' || player1=='P') && (player2=='L'|| player2=='R' || player2=='S' || player2=='C' || player2=='P') ){ //here check inputs are correct or not

   

   if(player1==player2){   // this if statement for check game is Tie
     
     output=1;
   
   }
   
   else if(player1=='L' && (player2=='S' || player2=='P')){
     
     output=2;
   
   }
   
   else if(player1=='R' && (player2=='L' || player2=='C')){
     
     output=2;
   
   } 
   
   else if(player1=='S' && (player2=='R' || player2=='C')){   // these if satements for check player 1 is wins 
     
     output=2;
   
   }
   
   else if(player1=='C' && (player2=='L' || player2=='P')){
     
     output=2;
   
   }  
   
   else if(player1=='P' && (player2=='R' || player2=='S')){
     
     output=2;
   
   }  
   
   else{
     
     output=3; // if not game is Tie or player 1 win here mark it as player 2 wins
   
   }
}





if(output==1){
  
   printf("Tie\n");

}

else if(output==2){
  
   printf("Player 1 wins\n");  // here print string according to output value

}

else if(output==3){
  
   printf("Player 2 wins\n");

}

else{
  
   printf("Wrong input\n");

}



return 0;

}
