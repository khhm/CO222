#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int toint(char []);

int main()
{

 char n[20];       // This is the variable to store input
 int i,valid=0;
 float bill;

 printf("Enter the number of units:\n");
 scanf("%s",n);
 
 while(isalnum(n[i]) != 0)        // loop until it a character is not alpha-numeric     
 {  
   if (isdigit(n[i]) == 0)
   {
     valid=1;                          
     break;
   }
   i++;
 }

int u=toint(n);  // Here get string input as a integer

 if(valid==1 || u<0)  // Check whether input is valid or invalid
 {
   printf("-1\n");
 }
 else
 {
  if (u<=60)                                    // In here check whether the units are below or higher than 60
  {
    if (u<30)                                   // In here check whether the units are below or higher than 30
      bill=u*2.50+30;
    else 
      bill=30*2.50+(u-30)*4.85+60;
  }

  else
  {
    if(u>180)
    {
      bill=60*7.85+30*10+30*27.75+60*32+(u-180)*45+540;
    }
    else if(u>120)
    {
      bill=60*7.85+30*10+30*27.75+(u-120)*32+480;
    }
    else if(u>90)
    {
      bill=60*7.85+30*10+(u-90)*27.75+480;
    } 
    else if(u>60)
    {
      bill=60*7.85+(u-60)*10+90;
    }
    else
    {
      bill=u*7.85;
    }
  }

    printf("The Total Monthly Bill is %.2f Rupees\n",bill); // Here display the bill to user
 }
return 0;
}


int toint(char str[])  // function for convert string to integer
{
  int len=strlen(str);
  int j=0;
  int num=0;

  for(j=0;j<len;j++)
  {
     num=num+((str[len-(j+1)]-'0')*pow(10,j));
  }
  return num;
}
