#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RESET		0
#define BRIGHT 		1

#define BLACK 		0
#define RED		1
#define GREEN		2
#define YELLOW		3
#define BLUE		4
#define MAGENTA		5
#define CYAN		6
#define	WHITE		7

void textcolor(int attr, int fg, int bg);

void textcolor(int attr, int fg, int bg)
{	char command[13];

	/* Command is the control command to the terminal */

	/* textcolor(BRIGHT,BLACK,WHITE) will have characters printed in
	black in white background */
	sprintf(command, "%c[%d;%d;%dm", 0x1B, attr, fg + 30, bg + 40);
	printf("%s", command);
}





int main(int argc, char **argv){

int checker=0,donut=0,backcolor=-1,forecolor=-1,rad=0,d;
int color[]={BLACK,RED,GREEN,YELLOW,BLUE,MAGENTA,CYAN,WHITE};
char input[][10]={"black","red","green","yellow","blue","magenta","cyan","white"}; // String array to compare input colours


if(argc < 4){
  printf("Not enough arguments\n");  // Here check whether number of arguments are correct
  return -1;
}else if(argc > 4){
  printf("Too many arguments\n");
  return -1;
}



if(!strcmp(argv[1],"checker")){
  checker=1;
}else if(!strcmp(argv[1],"donut")){     // Here check what figure is has to print and it is valid figure
  donut=1;
}else{
  printf("Requested figure is not available\n");
  return -1;
}



for(int a=0;a<8;a++){
  if(!strcmp(argv[2],input[a])){    // Here get integer assign to Background color
      backcolor=color[a];
  }
}

if(backcolor==-1){
  printf("Background color is not available\n");  // Here check Background color is available or not
  return -1;
}



for(int b=0;b<8;b++){
  if(!strcmp(argv[3],input[b])){     // Here get integer assign to Foreground color
      forecolor=color[b];
  }
}

if(forecolor==-1){
  printf("Foreground color is not available\n");  // Here check Background color is available or not
  return -1;
}




if(checker==1){
  for(int i=0;i<8;i++){
    for(int j=0;j<8;j++){
      for(int k=0;k<4;k++){
         if(i%2==1){ 
             textcolor(RESET, forecolor , backcolor); 
             printf("        "); 
             textcolor(RESET, backcolor , forecolor);
             printf("        ");
          
         }else{                                        // If figure is checker borad here print 8*8 checker board
             textcolor(RESET, backcolor , forecolor);
             printf("        ");
             textcolor(RESET, forecolor , backcolor);
             printf("        ");
         }
         textcolor(RESET, forecolor , backcolor);
      }
      printf("\n"); 
    }
  }
}




if(donut==1){

   scanf("%d",&rad);         // If figure is donut here ask to enter radius
   if(rad>0){                       //Here check radius is valid or not
       for(int i=0;i<rad;i++){
           for(int j=0;j<rad;j++){    
              
              d=(i-(rad/2))*(i-(rad/2))+(j-(rad/2))*(j-(rad/2));
              if(d+0.5<(double)rad/2*(double)rad/2  &&  d>(double)rad/4*(double)rad/4){    // Here print donut 
                textcolor(RESET, backcolor , forecolor);
                printf(" ");
              }
              else{
                textcolor(RESET, forecolor , backcolor);
                printf(" ");
              }
              textcolor(RESET, forecolor , backcolor);
           }
           printf("\n");
        }
 
   }else
        return -1;
}



	textcolor(RESET, WHITE, BLACK);	
	return 0;
	
}
