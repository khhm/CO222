#include<stdio.h>

int main(){
                                                                                                                                                               
int x,y,z,a,b,c,d;         // x-columns , y-rows , z = columns*3 
                           // a, b, c - for RGB values // d- for paddings

scanf("%d %d\n",&x,&y);   // here get size of image (columns*rows)

z=x*3;

while(1>0){        // here check whether bite length is multiple of 4

   if(z%4==0){
      break;
   }

z++;

}

printf("%d %d\n",x,y);


for(int i=0;i<y;i++){             // i,j,k are counter variables

   for(int j=0;j<x;j++){

      scanf("%d %d %d\n",&a,&b,&c);             // here original value get as input
      printf("%d %d %d\n",255-a,255-b,255-c);   // here original value convert to modify value and print

   }

   for(int k=0;k<z-(x*3);k++){     // here get and print padding

      scanf("%d\n",&d);         
      printf("%d\n",d);

   }

}

return 0;

}
